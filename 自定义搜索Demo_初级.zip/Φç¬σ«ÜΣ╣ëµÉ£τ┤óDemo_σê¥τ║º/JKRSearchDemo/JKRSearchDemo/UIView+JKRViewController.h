//
//  UIView+JKRViewController.h
//  JKRSearchDemo
//
//  Created by Joker on 2017/4/5.
//  Copyright © 2017年 Lucky. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (JKRViewController)

@property (nonatomic, strong, readonly) UIViewController *jkr_viewController;

@end
