//
//  JKRContactsViewController.m
//  JKRSearchDemo
//
//  Created by Lucky on 2017/4/4.
//  Copyright © 2017年 Lucky. All rights reserved.
//

#import "JKRContactsViewController.h"

@interface JKRContactsViewController ()

@end

@implementation JKRContactsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor redColor];
    self.jkr_lightStatusBar = YES;
}

@end
