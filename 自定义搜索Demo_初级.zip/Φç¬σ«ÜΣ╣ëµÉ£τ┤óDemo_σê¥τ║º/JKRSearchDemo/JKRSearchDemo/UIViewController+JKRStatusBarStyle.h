//
//  UIViewController+JKRStatusBarStyle.h
//  JKRTest
//
//  Created by Joker on 2016/5/7.
//  Copyright © 2016年 Lucky. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController (JKRStatusBarStyle)

@property (nonatomic, assign) BOOL jkr_lightStatusBar;

@end
