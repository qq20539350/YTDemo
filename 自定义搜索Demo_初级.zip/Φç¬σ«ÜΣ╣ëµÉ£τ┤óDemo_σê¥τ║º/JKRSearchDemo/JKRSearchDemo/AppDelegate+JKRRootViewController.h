//
//  AppDelegate+JKRRootViewController.h
//  JKRSearchDemo
//
//  Created by Lucky on 2017/4/4.
//  Copyright © 2017年 Lucky. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate (JKRRootViewController)

- (void)jkr_configRootViewController;

@end
