//
//  UIGestureRecognizer+JKRTouch.h
//  JKRTouchDemo
//
//  Created by Joker on 2016/12/31.
//  Copyright © 2016年 Lucky. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIGestureRecognizer (JKRTouch)

@property (nonatomic, assign) BOOL unTouch;

@end
