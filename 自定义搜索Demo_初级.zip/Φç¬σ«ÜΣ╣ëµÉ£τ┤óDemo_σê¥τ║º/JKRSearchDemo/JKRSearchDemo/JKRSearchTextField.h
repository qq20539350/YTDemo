//
//  JKRSearchTextField.h
//  JKRSearchDemo
//
//  Created by Joker on 2017/4/5.
//  Copyright © 2017年 Lucky. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JKRSearchTextField : UITextField

@property (nonatomic, assign) BOOL canTouch;

@end
