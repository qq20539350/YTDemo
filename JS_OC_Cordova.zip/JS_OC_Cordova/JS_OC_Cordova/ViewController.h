//
//  ViewController.h
//  JS_OC_Cordova
//
//  Created by Harvey on 16/9/28.
//  Copyright © 2016年 Haley. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CDVViewController.h"

@interface ViewController : CDVViewController


@end

